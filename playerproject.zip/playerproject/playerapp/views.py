from django.shortcuts import render,get_object_or_404,redirect
from playerapp.models import Player 
# Create your views here.
def lalala(request):
    return render(request,'lalala.html')
def home(request):
    search=request.GET.get("name",'')
    if search:
        player=Player.objects.filter(name__icontains=search)
    else:
        player=Player.objects.all()
    return render (request,'home.html',{'player':player})
def welcome(request):
    return render(request,'welcome.html')
def add(request):
    if request.method=="POST":
        name=request.POST['name']
        innings=request.POST['innings']
        runs=request.POST['runs']
        Player.objects.create(name=name,innings=innings,runs=runs)
        return redirect('home')
    return render(request,'add.html')
def edit(request,id):
    p=get_object_or_404(Player,id=id)
    if request.method=="POST":
        p.name=request.POST['name']
        p.innings=request.POST['innings']
        p.runs=request.POST['runs']
        p.save()
        return redirect('home')
    return render(request,'edit.html',{'p':p})
def delete(request,id):
    p=get_object_or_404(Player,id=id)
    p.delete()
    return redirect('home')