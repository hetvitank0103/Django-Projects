from django.urls import path
from playerapp.views import lalala,home,welcome,add,edit,delete
urlpatterns = [
    path('',lalala,name='lalala'),
    path('home/',home,name='home'),
    path('welcome/',welcome,name='welcome'),
    path('add/',add,name='add'),
    path('edit/<int:id>/',edit,name='edit'),
    path('delete/<int:id>/',delete,name='delete'),
]
