from django.db import models

# Create your models here.
class Players(models.Model):
    name=models.CharField()
    runs=models.IntegerField()
    profile=models.URLField()
    profile=models.EmailField()
    dob=models.DateField()
def __str__(self):
    return self.name
